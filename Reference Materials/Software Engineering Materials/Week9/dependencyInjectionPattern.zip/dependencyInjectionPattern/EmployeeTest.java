/*
 A container is an external entity which is responsible for object instantiation, 
configuration and overall object management.editor.
 */
package dependencyInjectionPattern;
 
public class EmployeeTest { 
    
      public static void main(String[] args) {
          
          Address myAddress = new Address();          
          Employee e = new Employee(myAddress);
          
          Employee e2 = new Employee();
          e2.setAddress(myAddress);
        
      }
    
}
