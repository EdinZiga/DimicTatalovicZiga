 
package dependencyInjectionPattern;

/**
 *
 * @author kanita
 */
public class Employee implements IAddress {
  
    //NOT GOOD PROGRAMMING PRACICE!!!,  This is hard-coded depenency, PROVIDES STRONG COUPLING!!!
     //Any change in Address will require code changes and recompilation of Employee class.
    //we want to decouple Employee from Address class.
    //private Address address = new Address();
    
    private Address address;
    
    //Constructor Injection: here dependenices are provided via constructor arguments
    // ‘Address’ object is created outside and injected to ‘Employee’ object as a constructor 
    //parameter, so ‘Employee’ does’t have to worry about address object creation.
    public Employee(Address _adress){
        this.address = _adress;
    }
    
     public Employee(){
         
    }
  
  
    public void sendGreetingCard(String greeting) {
       System.out.println("Some message: " + greeting + "setn to: " + address);
     }

    /**
     * Alternative way of providing injection, instead of in a Constructor
     * use setter method to pass the externally instantieted object to required class.
     * @param address 
     */
    public void setAddress(Address address){
        this.address = address;
    }
    
    
    public Address getAddress() {
       return this.address;
    }
 
}