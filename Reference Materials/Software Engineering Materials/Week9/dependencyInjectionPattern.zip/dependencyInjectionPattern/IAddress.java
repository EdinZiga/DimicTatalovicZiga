 
package dependencyInjectionPattern;

/**
 * 
 * 
 * Instead of depending on the Address class, Employee
 * can depend on the Address Interface, which has a method setAddress
 * implemented by Employee
 */
public interface IAddress {
    
     public void setAddress(Address address);
     
}
