 
package decoratorPattern;

/**
 *
 * @author kanita
 */
public interface Shape {
    
     public abstract void draw();
    
}
