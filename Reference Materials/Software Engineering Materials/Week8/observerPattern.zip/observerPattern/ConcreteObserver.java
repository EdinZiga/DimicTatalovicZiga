/*

 */
package observerPattern;

/**
 *
 * @author kanita
 */
public class ConcreteObserver implements Observer {
    
    private Observable observable;
    
    public ConcreteObserver(Observable o) {
        observable = o;
        observable.addObserver(this);
    }
    
    public void update() {
        System.out.println("The state of the Observable/Subject this Observer1/View is observing is: " + observable.getState());
        //the view of this observer will now get updated accodingn to Observable's state.
    }
}
