
package observerPattern;

/**
 *
 * @author kanita
 */
public class ObserverDriver {
    
    public static void main(String[] args) {
        
        Observable myObservable = new Observable(5);
        
        ConcreteObserver observer1 = new ConcreteObserver(myObservable);
        
        ConcreteObserver2 observer2 = new ConcreteObserver2(myObservable);
        
        myObservable.setState(1);
        myObservable.setState(3);
        
    }
    
}
