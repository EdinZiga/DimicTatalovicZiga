/*
<<Observer>> is an interface: any class that implements it can observe an <<Observable>>.
The dependency between the <<Observable>> classes and <<Observer>> classes is now transferred to <<Observable>> 
classes and the <<Observer>>s interface.

As the interface is stable, changes to the classes that implemented the interface do not affect the <<Observable>> classes.


 */
package observerPattern;

 
public interface Observer {
    
    public abstract void update();
    
}

