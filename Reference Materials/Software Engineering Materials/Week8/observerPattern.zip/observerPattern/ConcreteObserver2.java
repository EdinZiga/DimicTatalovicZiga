/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerPattern;

/**
 *
 * @author kanita
 */
public class ConcreteObserver2 implements Observer {
    
    private Observable observable;
    
    public ConcreteObserver2(Observable o) {
        observable = o;
        observable.addObserver(this);
    }
    
    public void update() {
        System.out.println("The state of the Observable/Subject this Observer2 is observing is: " + observable.getState());
    }
}
