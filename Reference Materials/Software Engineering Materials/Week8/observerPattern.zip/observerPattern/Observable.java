/*
Motivation 
–A common side-effect of partitioning a system into a collection of cooperating classes is the need to maintain consistency between related objects. 
–How can you achieve consistency? 

Intent 
–Define a one-to-many dependency between objects so that when one object changes state, all its dependents are notified and updated automatically. 

Reduce the coupling between classes, especially if they belong to different subsystems.
Maximize the flexibility.

 */
package observerPattern;

import java.util.ArrayList;

/**
 *
 * Ideally make this an abstract class.
 */
public class Observable {
    
    //maintains a list of observers
    private ArrayList<Observer> observers;
    
    private int state;
    
    
    public Observable(int n) {
        observers = new ArrayList<Observer>(n);
        state = 0;
    }
    
    public void addObserver(Observer o) {
        observers.add(o);              
    }
    
    public void removeObserver(Observer o) {
        observers.remove(o);
    }
    
     public int getState() {
        return state;
    }
    
    //when there is a change in the Observable, ie when state changes, all its Observers will be notified
    public void setState(int _state) {
        state = _state;
        notifyObservers();
    }
    
    //when there is a change in the Observable, ie when state changes, all its Observers will be notified
    public void notifyObservers() {
        for (int i = 0; i < observers.size(); i++) {
            observers.get(i).update();
        }
    }    
    
}
