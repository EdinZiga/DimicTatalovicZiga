/*
Problem:
Have to ensure that it is impossible to create more than one instance.
Having a public constructor means losing control of the object creation process → private constructor.
However, the singleton object itself must be accessible to other objects.

Ideally make this class an abstract class and cretae derived classes from Singleton.
 */
package singletonPattern;


public class Singleton {
    
    private static Singleton theInstance;
    
    private Singleton() {
        
    }
    
    public static Singleton getInstance() {
        
        if (theInstance == null) {
            theInstance = new Singleton();
            
        }
        return theInstance;        
    }
    
    public void doS() {
        System.out.println("Test");
    }
            
    
}
