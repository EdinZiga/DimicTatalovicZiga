/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package iteratorPattern;

/**
 *
 * @author kanita
 */
public class IteratorTest {
    
    public static void main(String[] args) {
          
          GameRepository games = new GameRepository(10);
          
          //System.out.println("Hello");
          
          //we want to iterate thru our Container (ie games), and 
          //in this case simply print its objects.
          //Move responsibility for access and traversal to a separate “iterator” object 
          for (Iterator iter = games.getIterator(); iter.hasNext();) {
              String s = (String)iter.next();  
              System.out.print(s);
              System.out.println(" has length: " + s.length());
          }
          
      }
    
}
