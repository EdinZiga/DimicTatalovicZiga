/*
Motivation 
–Don’t want to expose implementation details of the container AND want to allow multiple simultaneous traversals 
•Create separate interface/class that provide simple “hooks” 
–Often we want to say to a container (e.g., tree, graph, table, list, graphics): 
•Apply f() to each of your objects 
Intent 
–Provide a clean, abstract way to access all of the elements in an aggregate (container) without exposing the underlying representation 
–Move responsibility for access and traversal to a separate “iterator” object 

 */
package iteratorPattern;

import java.util.ArrayList;

/**
 *
 * @author kanita
 */
public class GameRepository implements Container {
    
    private ArrayList<String> games;
    
    public GameRepository(int n) {
        
         games = new ArrayList<String>(n);
         
         for (int i = 0; i < n; i++) {
             String g = "games" + i;
             games.add(g);                          
         }
    }
                
      public Iterator getIterator() {
          return new GameIterator();          
      }
      
      private class GameIterator implements Iterator {
          
         private int index = 0;
         
          public boolean hasNext() {
            return (index < games.size()); 
              
          }
            public String next() {
                if (hasNext()) {
                    String g =  games.get(index);
                    index++;
                    return g;
                }
                else return null;
                    
            }
                    
      }
      
      
    
}
