/*
Motivation 
–Don’t want to expose implementation details of the container AND want to allow multiple simultaneous traversals 
•Create separate interface/class that provide simple “hooks” 
–Often we want to say to a container (e.g., tree, graph, table, list, graphics): 
•Apply f() to each of your objects 
Intent 
–Provide a clean, abstract way to access all of the elements in an aggregate (container) without exposing the underlying representation 
–Move responsibility for access and traversal to a separate “iterator” object 

 */
package iteratorPattern;

/**
 *
 * @author kanita
 */
public interface Iterator {
    
    public boolean hasNext();
    public Object next();
    
}
